export type QuizQuestion = {
  q: string;
  options: string[];
  correct: number;
  explanation: string;
};

export type FlowNode = { id: string; label: string; caption?: string };

export type Session = {
  slug: string;
  number: number;
  title: string;
  subtitle: string;
  duration: string;
  day: number;
  brief: string;
  objectives: string[];
  whyItMatters: string;
  story: string;
  visual: {
    kind: "flow" | "layered" | "os-simulator";
    title: string;
    nodes: FlowNode[];
  };
  enterprise: {
    where: string;
    business: string;
    attacker: string;
    defender: string;
    incident: string;
  };
  concepts: { term: string; definition: string; example?: string }[];
  guidedLab: {
    title: string;
    goal: string;
    steps: { instruction: string; command?: string; expected?: string }[];
  };
  challenge: { title: string; prompt: string; hint: string };
  assessment: QuizQuestion[];
  summary: string;
  interviewQuestions: string[];
  careers: string[];
};

export const MONTH_1: Session[] = [
  {
    slug: "m1-bb1-os",
    number: 1,
    title: "Operating Systems",
    subtitle: "Kernel, Memory, Processes, and Boot",
    duration: "180 min",
    day: 1,
    brief:
      "An Enterprise OS Simulator covering Kernel, Processes, Threads, Memory, Filesystem, Permissions, Boot Process, BIOS, UEFI, and Virtual Memory.",
    objectives: [
      "Understand Kernel space vs User space",
      "Trace the Boot Process from BIOS/UEFI to init",
      "Analyze process context switching and threads",
      "Investigate memory allocation and virtual memory mapping",
    ],
    whyItMatters:
      "Every attack ultimately executes on an OS. Understanding the OS kernel and memory is required to hunt advanced threats.",
    story:
      "In 2010, Stuxnet loaded malicious drivers into the Windows kernel to hide its operations. By living in Ring 0, it bypassed all user-land antivirus.",
    visual: {
      kind: "os-simulator",
      title: "Enterprise OS Simulator",
      nodes: [],
    },
    enterprise: {
      where: "Windows Servers, Linux VMs, and employee endpoints.",
      business: "Uptime and stability of the underlying OS is critical for all applications.",
      attacker: "Attackers aim for privilege escalation to SYSTEM or root.",
      defender: "Defenders monitor process creation, unexpected services, and driver loads.",
      incident:
        "CrowdStrike (2024) - A bad kernel driver update caused millions of endpoints to crash.",
    },
    concepts: [
      { term: "Kernel", definition: "The core of the OS that manages CPU, memory, and devices." },
      { term: "Process", definition: "An executing instance of a program." },
      {
        term: "Virtual Memory",
        definition:
          "Memory management technique that provides an idealized abstraction of storage resources.",
      },
      {
        term: "Context Switch",
        definition:
          "Process of storing the state of a process/thread so it can be restored and resume execution.",
      },
    ],
    guidedLab: {
      title: "Enterprise Incident Investigation",
      goal: "Use the OS Simulator to find a hidden malicious process.",
      steps: [
        { instruction: "Open the Process Explorer.", command: "Launch OS Simulator" },
        { instruction: "Identify processes running under SYSTEM or root without a valid parent." },
        { instruction: "Terminate the anomalous process." },
      ],
    },
    challenge: {
      title: "Rootkit Detection",
      prompt:
        "A process is hiding from standard 'ps' output but you can see network connections. Where in the OS is the attacker hiding?",
      hint: "Think about Kernel vs User space hooks.",
    },
    assessment: [
      {
        q: "What is the primary role of the Kernel?",
        options: [
          "Running user applications",
          "Managing hardware and system resources",
          "Rendering UI",
          "Providing network cables",
        ],
        correct: 1,
        explanation: "The kernel bridges hardware and software.",
      },
      {
        q: "What is Virtual Memory?",
        options: [
          "RAM installed physically",
          "Abstraction of memory that allows processes to act as if they have contiguous memory",
          "Cloud storage",
          "ROM",
        ],
        correct: 1,
        explanation: "Virtual memory maps logical addresses to physical addresses.",
      },
    ],
    summary:
      "You can now investigate the lowest levels of an operating system, mapping processes to memory and tracking boot sequences.",
    interviewQuestions: [
      "Explain the difference between User space and Kernel space.",
      "How does a computer boot from UEFI to the login prompt?",
    ],
    careers: ["Threat Hunter", "Incident Response", "System Administrator"],
  },
  {
    slug: "m1-bb2-networking",
    number: 2,
    title: "Networking",
    subtitle: "Enterprise Packet Journey",
    duration: "180 min",
    day: 5,
    brief: "Placeholder for Networking Building Block.",
    objectives: ["Understand OSI Model", "Analyze TCP/IP"],
    whyItMatters: "Networks connect the enterprise.",
    story: "Placeholder",
    visual: { kind: "flow", title: "Network", nodes: [] },
    enterprise: { where: "", business: "", attacker: "", defender: "", incident: "" },
    concepts: [],
    guidedLab: { title: "", goal: "", steps: [] },
    challenge: { title: "", prompt: "", hint: "" },
    assessment: [],
    summary: "",
    interviewQuestions: [],
    careers: [],
  },
  {
    slug: "m1-bb3-linux",
    number: 3,
    title: "Linux",
    subtitle: "Enterprise Linux Operations",
    duration: "180 min",
    day: 10,
    brief: "Placeholder for Linux Building Block.",
    objectives: [],
    whyItMatters: "",
    story: "",
    visual: { kind: "flow", title: "Linux", nodes: [] },
    enterprise: { where: "", business: "", attacker: "", defender: "", incident: "" },
    concepts: [],
    guidedLab: { title: "", goal: "", steps: [] },
    challenge: { title: "", prompt: "", hint: "" },
    assessment: [],
    summary: "",
    interviewQuestions: [],
    careers: [],
  },
  {
    slug: "m1-bb4-windows",
    number: 4,
    title: "Windows",
    subtitle: "Enterprise Windows",
    duration: "180 min",
    day: 15,
    brief: "Placeholder for Windows Building Block.",
    objectives: [],
    whyItMatters: "",
    story: "",
    visual: { kind: "flow", title: "Windows", nodes: [] },
    enterprise: { where: "", business: "", attacker: "", defender: "", incident: "" },
    concepts: [],
    guidedLab: { title: "", goal: "", steps: [] },
    challenge: { title: "", prompt: "", hint: "" },
    assessment: [],
    summary: "",
    interviewQuestions: [],
    careers: [],
  },
  {
    slug: "m1-bb5-security-concepts",
    number: 5,
    title: "Security Concepts",
    subtitle: "CIA, AAA, IAM, and Crypto",
    duration: "180 min",
    day: 20,
    brief: "Placeholder for Security Concepts Building Block.",
    objectives: [],
    whyItMatters: "",
    story: "",
    visual: { kind: "flow", title: "Concepts", nodes: [] },
    enterprise: { where: "", business: "", attacker: "", defender: "", incident: "" },
    concepts: [],
    guidedLab: { title: "", goal: "", steps: [] },
    challenge: { title: "", prompt: "", hint: "" },
    assessment: [],
    summary: "",
    interviewQuestions: [],
    careers: [],
  },
  {
    slug: "m1-bb6-enterprise-infrastructure",
    number: 6,
    title: "Enterprise Infrastructure",
    subtitle: "Interactive Enterprise Digital Twin",
    duration: "180 min",
    day: 25,
    brief: "Placeholder for Enterprise Infrastructure Building Block.",
    objectives: [],
    whyItMatters: "",
    story: "",
    visual: { kind: "flow", title: "Infra", nodes: [] },
    enterprise: { where: "", business: "", attacker: "", defender: "", incident: "" },
    concepts: [],
    guidedLab: { title: "", goal: "", steps: [] },
    challenge: { title: "", prompt: "", hint: "" },
    assessment: [],
    summary: "",
    interviewQuestions: [],
    careers: [],
  },
  {
    slug: "m1-bb7-risk",
    number: 7,
    title: "Risk Awareness",
    subtitle: "Business Impact and Compliance",
    duration: "180 min",
    day: 30,
    brief: "Placeholder for Risk Awareness Building Block.",
    objectives: [],
    whyItMatters: "",
    story: "",
    visual: { kind: "flow", title: "Risk", nodes: [] },
    enterprise: { where: "", business: "", attacker: "", defender: "", incident: "" },
    concepts: [],
    guidedLab: { title: "", goal: "", steps: [] },
    challenge: { title: "", prompt: "", hint: "" },
    assessment: [],
    summary: "",
    interviewQuestions: [],
    careers: [],
  },
];

export const PROGRAM_MONTHS = [
  {
    number: 1,
    title: "CyberOS Foundations",
    subtitle: "OS, Network, Infra, Risk",
    days: "Day 1 → 30",
    status: "active" as const,
    sessionCount: MONTH_1.length,
  },
  {
    number: 2,
    title: "SOC Analyst",
    subtitle: "Detect, investigate, respond",
    days: "Day 31 → 60",
    status: "locked" as const,
    sessionCount: 8,
  },
  {
    number: 3,
    title: "Ethical Hacking",
    subtitle: "Attacker methodology",
    days: "Day 61 → 90",
    status: "locked" as const,
    sessionCount: 8,
  },
  {
    number: 4,
    title: "VAPT & Projects",
    subtitle: "Real assessments and portfolio",
    days: "Day 91 → 120",
    status: "locked" as const,
    sessionCount: 8,
  },
];

export function getSession(slug: string): Session | undefined {
  return MONTH_1.find((s) => s.slug === slug);
}
